<?php $__env->startSection('title', 'New Feeds'); ?>
<?php $__env->startSection('content'); ?>
    <a class="delete is-large" href="<?php echo e(route('news.index')); ?>" style="margin: 1px 90%;"></a>

    <div class="row">
        <div class="col-xs-12">
            <div class="form-group">
                <h3>Title: <?php echo e($feeds->title); ?></h3>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="form-group">
                <h2>Content:  <?php echo e($feeds->content); ?></h2>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="form-group">
                <h2>Image:  <img src="<?php echo e('/images/' . $feeds->image); ?>"</h2>

            </div>
        </div>
    </div>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>